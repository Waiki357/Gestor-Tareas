#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDebug>
#include "dbconnection.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    //tareas
    void onAddTarea();
    void onTareasCellChanged(int row, int column);
    void onLoadTareas();
    void onDescripcionTareas(int row, int column);
    void onActualizarDescripcionTareas(int row);
    //Categorias
    void onAddCategoria();
    void onCategoriaCellChanged(int row, int column);
    void onCambiarCategoria(int row);
    //Etiquetas
    void onAddEtiqueta();
    void onEtiquetaCellChanged(int row, int column);

private:
    Ui::MainWindow *ui;
    QSqlDatabase db_;
    bool addingTarea_;
    bool addingCategoria_;
    bool addingEtiqueta_;
};

#endif // MAINWINDOW_H
